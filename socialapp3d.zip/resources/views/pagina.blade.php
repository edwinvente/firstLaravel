@extends('layouts.master')

@section('titulo', 'Master en Laravel')

@section('header')
	@parent()
	<h2>Hello</h2>
@stop

@section('content')
	<h1>Contenido de la página generica</h1>
@stop