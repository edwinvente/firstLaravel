<h1>Detalle de pelicula</h1>
<a href="{{ action('PeliculaController@index') }}">Ir al listado</a>