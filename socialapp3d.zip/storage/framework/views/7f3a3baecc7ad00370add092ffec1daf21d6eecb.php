<?php if($personas && count($personas) >=1): ?>
	<p>Existen las personas</p>
	<?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<ul>
			<li><?php echo e($persona); ?></li>
		</ul>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<p>Hay en mi lista: <?php echo e(count($personas)); ?> personas</p>
<?php else: ?>
	<p>No existen personas</p>
<?php endif; ?>