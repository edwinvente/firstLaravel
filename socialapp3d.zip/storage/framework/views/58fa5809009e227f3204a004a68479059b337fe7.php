<h1>Detalle de pelicula</h1>
<a href="<?php echo e(action('PeliculaController@index')); ?>">Ir al listado</a>