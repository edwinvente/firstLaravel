<h1><?php echo e($titulo); ?></h1>
<p>Los personajes principales son</p>
<?php if(count($listado) > 0): ?>
	<?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<ul>
			<li><?php echo e($personaje); ?></li>
		</ul>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
	<p>No hay personajes este año</p>
<?php endif; ?>

<?php echo isset($director)? $director:'No hay director'; ?>
