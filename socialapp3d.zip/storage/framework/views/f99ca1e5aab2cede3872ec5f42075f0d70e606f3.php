<?php $__env->startSection('titulo', 'Master en Laravel'); ?>

<?php $__env->startSection('header'); ?>
	##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
	<h2>Hello</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Contenido de la página generica</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>