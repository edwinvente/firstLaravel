<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Página Laravel - <?php echo $__env->yieldContent('titulo'); ?></title>
</head>
<body>
	<?php $__env->startSection('header'); ?>
		<h1>Cabecera de la web Master</h1>
	<?php echo $__env->yieldSection(); ?>
	<hr>

	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>

	<hr>
	<?php $__env->startSection('footer'); ?>
		<h1>Pie de pagina de la web Master</h1>
	<?php echo $__env->yieldSection(); ?>
</body>
</html>	