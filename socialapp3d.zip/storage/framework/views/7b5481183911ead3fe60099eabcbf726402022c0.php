<h1><?php echo e($titulo); ?></h1>

<p>(Accion index del controlador de peliculas)</p>
<?php if(isset($pagina)): ?>
	La pagina es: <h3><?php echo e($pagina); ?></h3>
<?php endif; ?>

<a href="<?php echo e(route('detalle.pelicula')); ?>">Ir al detalle</a>